<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Post extends Model
{
       use SoftDeletes;

       protected $fillable = ['title', 'content', 'status'];

       // Scope: hanya post yang sudah dipublikasikan
       public function scopePublished(Builder $query): Builder
       {
              return $query->where('status', 'published');
       }
}
